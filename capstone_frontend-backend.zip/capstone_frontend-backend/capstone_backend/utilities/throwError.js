export function throwError(err) {
  throw new Error(err);
}
